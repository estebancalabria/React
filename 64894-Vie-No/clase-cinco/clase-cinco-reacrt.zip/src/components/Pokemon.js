import React, { Component } from 'react';


class Pokemon extends Component {
    state = {  } 
    render() { 
        return (<h1>Pokemon API</h1>);
    }
}
 
export default Pokemon;